function getservice(){
    //return 'http://localhost/jio/';
    return 'http://coderaavana.in/cr_jio/';
   }
   